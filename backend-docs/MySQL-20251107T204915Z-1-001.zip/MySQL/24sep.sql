-- alter command
-- add a column
USE schooldb;
/*ALTER TABLE STUDENTS
ADD COLUMN PHNO INT NOT NULL 
after email;
-- rename the column
ALTER TABLE students
RENAME COLUMN PHNO to ph_no;
-- modify the column
ALTER TABLE students
MODIFY ph_no char(10);

-- delete the column
ALTER TABLE students
drop COLUMN ph_no;*/

-- TRUNCATE 
-- TRUNCATE TABLE students;
--  rename students table as stdnts;
-- RENAME TABLE students to stdnts;




















